@extends('master')

@section('content')
	<div class="jumbotron">
	  <h1>Oops!! Page Not Found</h1>
		  
		  <p><a href="/" class="btn btn-primary btn-lg">Go to Home</a></p>
	  </div>
@stop